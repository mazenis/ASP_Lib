﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class SBSubject : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {



       }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //DataSet data1 = new DataSet();
        //string keywords = TextBox1.Text.Trim();
        //if (keywords == "") return;
        //string[] keywordsArray = keywords.Split(' ');
        //try
        //{
            //for (int i = 0; i < keywordsArray.Length; i++)
          //  {
                    
        //    }
        //}
        //catch (Exception ex)
        //{

       // }
    }


}
